export default ToggleInteraction;
export type ToggleInteractionOptions = {
    /**
     * - Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
    /**
     * - Interaction à ajouter.
     */
    interaction?: Interaction | undefined;
};
/**
 * @typedef {Object} ToggleInteractionOptions
 * @property {String} [label] - Libellé associé à l'input.
 * @property {String} [title] - Attribut title / aria-label.
 * @property {String} [position] - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
 * @property {String|HTMLElement} [icon] - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
 * @property {import("ol/interaction").Interaction} [interaction] - Interaction à ajouter.
 */
/**
 * @classdesc
 * Contrôle de base créant un toggle avec interaction.
 *
 * @alias ol.control.ToggleInteraction
 * @module Toggle
 */
declare class ToggleInteraction extends Toggle {
    /**
     * Constructeur du contrôle ToggleInteraction.
     * @constructor
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    constructor(options: ToggleInteractionOptions);
    /**
     * Initialise le contrôle ToggleInteraction (appelé par le constructeur).
     * @protected
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    protected _initialize(options: ToggleInteractionOptions): void;
    _boundIntChangeActive: any;
    /**
     * Ajoute les écouteurs d'événements sur les éléments du contrôle.
     * @protected
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    protected _initEvents(options: ToggleInteractionOptions): void;
    /**
     * Ajoute une interaction au toggle. Enlève la précédente interaction de la carte.
     * @param {Interaction} [interaction] Interaction openlayer
     */
    setInteraction(interaction?: Interaction): void;
    interaction: Interaction | undefined;
    /**
     * Retourne l'interaction lié au toggle.
     * @returns {Interaction} Interaction openlayer (si elle existe)
     */
    getInteraction(): Interaction;
    _onInteractionChangeActive(e: any): void;
}
import { Interaction } from "ol/interaction";
import Toggle from "./Toggle";
//# sourceMappingURL=ToggleInteraction.d.ts.map