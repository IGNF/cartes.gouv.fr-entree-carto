export default TabNavItem;
/**
 * Objet représentant un item de navigation tertiaire
 */
export type TabNavItemOptions = {
    /**
     * - Label du bouton
     */
    label: string;
    /**
     * - Contenu lié au bouton
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Titre du bouton
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du bouton
     */
    icon?: string | undefined;
    /**
     * - Callback appelé à l'ouverture de l'onglet
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture de l'onglet
     */
    onClose?: Function | undefined;
};
/**
 * Objet représentant un item de navigation tertiaire
 * @typedef {Object} TabNavItemOptions
 * @property {String} label - Label du bouton
 * @property {String|HTMLElement} [content] - Contenu lié au bouton
 * @property {String} [title] - Titre du bouton
 * @property {String} [icon] - Classe CSS de l'icône du bouton
 * @property {Function} [onOpen] - Callback appelé à l'ouverture de l'onglet
 * @property {Function} [onClose] - Callback appelé à la fermeture de l'onglet
 */
/**
 * @classdesc
 * Classe gérant une navigation tertiaire avec onglets.
 *
 * @alias TabNavItem
 * @module TabNavItem
 * @extends {Control}
 */
declare class TabNavItem extends Control {
    /**
     * Constructeur du TabNavItem.
     * @constructor
     * @param {TabNavItemOptions} options Options du constructeur
     */
    constructor(options?: TabNavItemOptions);
    /**
     * @param {TabNavItemOptions} options Options de construction
     */
    _initialize(options: TabNavItemOptions): void;
    tabNavItemClass: string | undefined;
    _uid: any;
    selectors: {
        OPEN_TAB: string;
        CLOSE_TAB: string;
    } | undefined;
    onOpen: Function | undefined;
    onClose: Function | undefined;
    /**
     * Crée le conteneur principal de la navigation.
     * @protected
     * @param {TabNavItemOptions} options Options de construction
     * @returns {HTMLElement} Élément div de navigation
     */
    protected _initContainer(options: TabNavItemOptions): HTMLElement;
    button: HTMLButtonElement | undefined;
    content: HTMLDivElement | undefined;
    /**
     * @param {TabNavItemOptions} options Options du constructeur
     */
    _initEvents(options: TabNavItemOptions): void;
    /**
     * Retourne l'élément principal de la navigation.
     * @returns {HTMLElement} Élément div de navigation
     */
    getElement(): HTMLElement;
    /**
     * Retourne le bouton de l'item.
     * @returns {HTMLButtonElement} Élément div de navigation
     */
    getButton(): HTMLButtonElement;
    /**
     * Retourne le contenu de l'item.
     *
     * Attention, cela est différent du conteneur dans lequel il se trouve
     * @returns {HTMLElement} Élément div de navigation
     */
    getContent(): HTMLElement;
    /**
     * Affiche le contenu.
     */
    show(): void;
    /**
     * Masque le contenu.
     */
    hide(): void;
    /**
     * Sélectionne ou déselectionne l'item
     * @param {Boolean} bool Vrai si l'élément doit être sélectionné.
     */
    setSelected(bool: boolean): void;
    /**
     * Vérifie si l'élément est sélectionné
     * @return {Boolean} Vrai si l'élément est sélectionné.
     */
    isSelected(): boolean;
}
import Control from "../Control";
//# sourceMappingURL=TabNavItem.d.ts.map