/**
 * Options de base du toggle
 */
type ToggleOptions = {
    /**
     * - Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
};
type ToggleContentOptions = {
    /**
     * - Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
    /**
     * - Contenu à ajouter.
     */
    content?: string | undefined;
    /**
     * - Taille du panneau ("sm" ou "lg").
     */
    size?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Position du panneau ("left" ou "right").
     */
    dialogPosition?: string | undefined;
};
type ToggleInteractionOptions = {
    /**
     * - Libellé associé à l'input.
     */
    label?: string | undefined;
    /**
     * - Attribut title / aria-label.
     */
    title?: string | undefined;
    /**
     * - Position CSS du widget sur la carte. Valeurs acceptées : `top-right`, `top-left`, `bottom-right` ou `bottom-left`. Si non donné, le contrôle doit être positionné en CSS.
     */
    position?: string | undefined;
    /**
     * - Classe à ajouter au bouton ou élément svg (inline) ou élément HTML à ajouter avant le label (type span).
     */
    icon?: string | HTMLElement | undefined;
    /**
     * - Interaction à ajouter.
     */
    interaction?: import("ol/interaction").Interaction | undefined;
};
/**
 * Options du constructeur Dialog
 */
type DialogOptions = {
    /**
     * - Identifiant unique du dialog
     */
    id?: string | undefined;
    /**
     * - Titre du dialog
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du dialog
     */
    icon?: string | undefined;
    /**
     * - Contenu du dialog (HTML string ou élément DOM)
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Position du dialog ("left" ou "right")
     */
    position?: string | undefined;
    /**
     * - Taille du dialog ("sm" ou "md")
     */
    size?: string | undefined;
    /**
     * - Nom de classe CSS additionnel
     */
    className?: string | undefined;
    /**
     * - Liste des items de navigation tertiaire
     */
    items?: TabNavItemOptions[] | undefined;
    /**
     * - Attribut aria label de la navigation tertiaire
     */
    labelTabNav?: string | undefined;
    /**
     * - Callback appelé à l'ouverture du dialog
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture du dialog
     */
    onClose?: Function | undefined;
};
/**
 * Objet représentant un item de navigation tertiaire
 */
type TabNavItemOptions = {
    /**
     * - Label du bouton
     */
    label: string;
    /**
     * - Contenu lié au bouton
     */
    content?: string | HTMLElement | undefined;
    /**
     * - Titre du bouton
     */
    title?: string | undefined;
    /**
     * - Classe CSS de l'icône du bouton
     */
    icon?: string | undefined;
    /**
     * - Callback appelé à l'ouverture de l'onglet
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture de l'onglet
     */
    onClose?: Function | undefined;
};
/**
 * Options du constructeur TabNav
 */
type TabNavOptions = {
    /**
     * - Liste des items de navigation
     */
    items?: TabNavItemOptions[] | undefined;
    /**
     * - Label ARIA de la navigation
     */
    label?: string | undefined;
    /**
     * - Conteneur du contenu lié aux onglets. Si non fourni, en créé un et l'ajoute juste après les liens.
     */
    contentContainer?: HTMLElement | undefined;
};
//# sourceMappingURL=typedefs.d.ts.map