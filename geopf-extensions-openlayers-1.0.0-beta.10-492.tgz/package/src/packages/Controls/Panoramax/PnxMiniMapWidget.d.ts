export default MiniMap;
/**
 * Webcomponent Panoramax affichant le controle GeoportalOverviewMap (DSFR).
 */
declare class MiniMap extends LitElement {
    _map: any;
    _options: {};
    _overviewControl: GeoportalOverviewMap | null;
    _isSyncingView: boolean;
    _onMainMapMoveEnd: (() => void) | null;
    _onMiniMapMoveEnd: (() => void) | null;
    _container: Element | null;
    createRenderRoot(): this;
    firstUpdated(): void;
    set map(map: any);
    get map(): any;
    set options(options: {});
    get options(): {};
    _getOptionsFromAttribute(): any;
    _applyMiniMapSize(): void;
    _onViewSync(): void;
    _unViewSync(): void;
    _renderOverviewMap(): void;
    render(): import("lit-html").TemplateResult<1>;
    _removeOverviewMap(): void;
}
import { LitElement } from "lit";
import GeoportalOverviewMap from "../OverviewMap/GeoportalOverviewMap";
//# sourceMappingURL=PnxMiniMapWidget.d.ts.map