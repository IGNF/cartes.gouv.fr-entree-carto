/**
 * @file Fichiers liés au scroll / à la visibilité d'éléments.
 * @see {@link https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/} Pour plus d'infos.
 */
/**
 * Indique si l'élément est visible dans la vue courante
 * @param {Element} element Élément à vérifier
 * @returns {Boolean} Vrai si l'élément est visible.
 */
export function isElementInView(element: Element): boolean;
/**
 * Vérifie si un élément est scrollable ou non
 * @param {Element} element Élément à vérifier
 * @returns {Boolean} Vrai si c'est le cas.
 */
export function isScrollable(element: Element): boolean;
/**
 * Vérifie si un élément enfant est dans l'aire de scroll de son parent.
 * Si ce n'est pas le cas, scroll au niveau du parent
 * @param {Element} activeElement Élément actif (élément enfant)
 * @param {Element} scrollParent Élément parent
 */
export function maintainScrollVisibility(activeElement: Element, scrollParent: Element): void;
//# sourceMappingURL=Scroll.d.ts.map