export default DefaultInput;
export type DefaultInputConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Type de l'input
     */
    type?: string | undefined;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Les options de la sélection (valeur: libellé)
     */
    options: {
        [x: string]: string;
    };
};
/**
 * @typedef {Object} DefaultInputConfig
 * @property {string} label Le label de l'input
 * @property {string} [labelInfo] Info supplémentaire du label (ex: unité)
 * @property {string} property La propriété flat style correspondante
 * @property {string} [type] Type de l'input
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 * @property {Object<string, string>} options Les options de la sélection (valeur: libellé)
 */
/**
 * @fires change Changement de valeur pour le
 */
declare class DefaultInput extends ControlExtended {
    /**
     * Constructeur du contrôle DefaultInput
     * @param {DefaultInputConfig} options Options du contrôle
     */
    constructor(options?: DefaultInputConfig);
    /**
     * @param {DefaultInputConfig} options Options du contrôle
     * @override
     */
    override _initialize(options: DefaultInputConfig): void;
    property: string | undefined;
    type: string | undefined;
    /**
     * @param {DefaultInputConfig} options Options du contrôle
     * @override
     */
    override _initContainer(options: DefaultInputConfig): void;
    label: HTMLLabelElement | undefined;
    inputContainer: HTMLDivElement | undefined;
    input: HTMLInputElement | undefined;
    /**
     * @param {DefaultInputConfig} options Options du contrôle
     * @override
     */
    override _initEvents(options: DefaultInputConfig): void;
    /**
     * Désactive / active l'input.
     * @param {Boolean} bool Vrai si l'input doit être désactivé
     */
    setDisabled(bool: boolean): void;
    /**
     * Retourne l'élément
     * @returns {HTMLElement} Élément principal
     */
    getElement(): HTMLElement;
    /**
     * Retourne l'input
     * @returns {HTMLInputElement} Input du contrôle
     */
    getInput(): HTMLInputElement;
}
import ControlExtended from "../Control.js";
//# sourceMappingURL=DefaultInput.d.ts.map