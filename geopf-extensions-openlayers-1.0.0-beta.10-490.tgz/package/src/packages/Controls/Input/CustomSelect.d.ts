export default CustomSelect;
export type CustomSelectConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Type de l'input
     */
    type?: string | undefined;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Les options de la sélection (valeur: libellé)
     */
    options: {
        [x: string]: string;
    };
};
/**
 * @typedef {Object} CustomSelectConfig
 * @property {string} label Le label de l'input
 * @property {string} [labelInfo] Info supplémentaire du label (ex: unité)
 * @property {string} property La propriété flat style correspondante
 * @property {string} [type] Type de l'input
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 * @property {Object<string, string>} options Les options de la sélection (valeur: libellé)
 */
/**
 * @see {@link https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/} Pour voir l'inspiration pour les contrôles clavier
 */
declare class CustomSelect extends DefaultInput {
    baseOptionId: string | undefined;
    open: boolean | undefined;
    /**
     * Liste des actions possibles au clavier
     */
    selectActions: {
        Close: number;
        CloseSelect: number;
        Open: number;
        First: number;
        Last: number;
        Down: number;
        Up: number;
        PageDown: number;
        PageUp: number;
        Left: number;
        Right: number;
        BeginRow: number;
        EndRow: number;
        Select: number;
        Type: number;
    } | undefined;
    pageSize: number | undefined;
    isDragging: boolean | undefined;
    dragFct: any;
    stopDraggingFct: any;
    choices: [string, string][] | undefined;
    options: {
        [x: string]: string;
    } | undefined;
    choice: HTMLSpanElement | undefined;
    optionsContainer: HTMLDivElement | undefined;
    dragDiv: HTMLDivElement | undefined;
    dragHandle: HTMLDivElement | undefined;
    optionsContent: HTMLDivElement | undefined;
    /**
     * Mets l'élément en "aria-selected = true" et déselectionne l'élément courant.
     * @param {Element} elem Élément à sélectionner
     */
    setCurrentOption(elem: Element): void;
    /**
     * Retourne l'élément sélectionné dans les options
     * @returns {Element | null} Item sélectionné
     */
    getCurrentOption(): Element | null;
    /**
     * Commence à dragger la modale
     * @param {MouseEvent|TouchEvent} e Événement à gérer
     */
    startDragging(e: MouseEvent | TouchEvent): void;
    startY: any;
    startHeight: number | undefined;
    /**
     * Bouge la modale
     * @param {MouseEvent|TouchEvent} e Événement à gérer
     */
    drag(e: MouseEvent | TouchEvent): void;
    /**
     * Arrête de bouger la modale
     */
    stopDragging(): void;
    /**
     * Renvoie une action en fonction de l'événement de clavier.
     * @see {@link https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/} Pour plus d'info
     * @param {KeyboardEvent} event Événement à gérer
     * @param {Boolean} menuOpen Vrai si le menu est ouvert
     * @returns {Number} Nombre correspondant à l'action
     */
    getActionFromKey(event: KeyboardEvent, menuOpen: boolean): number;
    /**
     * Gère l'événement `click` sur la liste de choix / le bouton select
     * @param {MouseEvent} event Événement à gérer
     */
    onComboClick(event: MouseEvent): void;
    /**
     * Gère l'événement `blur` ou `focusout` sur la liste de choix / le bouton select
     * @param {FocusEvent} event Événement à gérer
     */
    onComboBlur(event: FocusEvent): void;
    /**
     * Fonction gérant les événements clavier pour la liste
     * @param {KeyboardEvent} event Événement de clavier à gérer
     * @returns {void}
     */
    onComboKeyDown(event: KeyboardEvent): void;
    /**
     * Ferme le panneau de sélection
     * @param {Boolean} bool Vrai si on doit fermer le panneau
     */
    collapse(bool: boolean): void;
    initialHeight: number | false | undefined;
    /**
     * Vérifie si l'élément est visible et si ce n'est pas
     * ajuste sa position
     */
    setVisible(): void;
    /**
     * Indique si le panneau des options est ouvert.
     * @returns {Boolean} Vrai si le panneau est fermé. Faux sinon.
     */
    isCollapsed(): boolean;
    /**
     * Change l'indice de sélection en fonction de l'action en cours
     * @param {Number} currentIndex Indice courrant
     * @param {Number} maxIndex Indice max
     * @param {Number} action Type d'action
     * @returns {Number} nouvel indice
     */
    getUpdatedIndex(currentIndex: number, maxIndex: number, action: number): number;
    /**
     * Sélectionne une option et envoi un événement `change` sur l'input.
     * @param {Number} index Indice de l'élément à sélectionner
     * @param {Boolean} silent Si vrai, n'envoie pas d'événement change
     * @returns {Boolean} Vrai si l'option est sélectionnée
     */
    selectOption(index: number, silent?: boolean): boolean;
    activeIndex: number | undefined;
    /**
     * Gère le changement d'option
     * @param {Number} [index] Indice de l'option à sélectionner
     */
    onOptionChange(index?: number): void;
    /**
     * Gère les différentes actions à mettre en place au clic sur une option
     * @param {Number} index Indice de l'option cliqué
     */
    onOptionClick(index: number): void;
    /**
     * Gère la réaction en cas d'écriture dans l'interface (pour l'instant ne fait rien)
     * @param {String} key Touche clavier
     * @returns {void}
     */
    onComboType(key: string): void;
    /**
     * Créé une option avec une valeur et un label
     * @param {String} value Valeur du choix (dépend de la propriété)
     * @param {String} label Libellé à afficher
     * @param {Number} index Indice de l'élément (utile pour les raccourcis claviers)
     * @returns {HTMLButtonElement} Option à ajouter
     */
    addChoice(value: string, label: string, index: number): HTMLButtonElement;
}
import DefaultInput from "./DefaultInput.js";
//# sourceMappingURL=CustomSelect.d.ts.map