export default StyleDialog;
/**
 * Options du constructeur du dialogue de style
 */
export type StyleDialogOptions = {
    /**
     * - Identifiant unique du dialog
     */
    id?: string | undefined;
    /**
     * - Titre du dialog
     */
    title?: string | undefined;
    /**
     * - Interaction de sélection. Si fournie, lie l'ouverture du dialogue avec la sélection d'un objet (écoute de l'événement `select.on("select")`)
     */
    select?: Select | undefined;
    /**
     * Formulaires de style, avec un titre et un label pour la navigation. Si vide ou nul, des formulaires par défauts seront ajoutés :
     * - `Style` : Modification du style (voir fichier {@link  ./styleForm.js} )
     * - `Texte` : Modification de l'éqtiquette (voir fichier {@link  ./labelForm.js} )
     */
    forms?: StyleDialogTabNav[] | undefined;
    /**
     * - Classe CSS de l'icône du dialog
     */
    icon?: string | undefined;
    /**
     * - Position du dialog ("left" ou "right")
     */
    position?: string | undefined;
    /**
     * - Taille du dialog ("sm" ou "md")
     */
    size?: string | undefined;
    /**
     * - Nom de classe CSS additionnel
     */
    className?: string | undefined;
    /**
     * - Callback appelé à l'ouverture du dialog
     */
    onOpen?: Function | undefined;
    /**
     * - Callback appelé à la fermeture du dialog
     */
    onClose?: Function | undefined;
};
/**
 * Configuration pour un type input
 */
export type InputConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Le type de l'input. Peut aussi être un type `select`, auquel cas l'élément ajouté est un élément select.
     * Peut être un objet avec une methode getInput()/getElement() pour les inputs personnalisés
     */
    type: string | any;
    /**
     * Les options du select (valeur: libellé)
     */
    options: any;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
};
/**
 * Options pour une navigation tertiaire du dialog de style.
 */
export type StyleDialogTabNav = {
    /**
     * Libellé de la navigation.
     */
    label: string;
    /**
     * Formulaire de style correspondant.
     */
    form: FlatStyleForm;
    /**
     * Titre associé (attribut title).
     */
    title?: string | undefined;
};
/**
 * @typedef StyleDialogOptions Options du constructeur du dialogue de style
 * @property {String} [id] - Identifiant unique du dialog
 * @property {String} [title] - Titre du dialog
 * @property {Select} [select] - Interaction de sélection. Si fournie, lie l'ouverture du dialogue avec la sélection d'un objet (écoute de l'événement `select.on("select")`)
 * @property {Array<StyleDialogTabNav>} [forms] Formulaires de style, avec un titre et un label pour la navigation. Si vide ou nul, des formulaires par défauts seront ajoutés :
 * - `Style` : Modification du style (voir fichier {@link ./styleForm.js} )
 * - `Texte` : Modification de l'éqtiquette (voir fichier {@link ./labelForm.js} )
 * @property {String} [icon] - Classe CSS de l'icône du dialog
 * @property {String} [position="right"] - Position du dialog ("left" ou "right")
 * @property {String} [size="md"] - Taille du dialog ("sm" ou "md")
 * @property {String} [className] - Nom de classe CSS additionnel
 * @property {Function} [onOpen] - Callback appelé à l'ouverture du dialog
 * @property {Function} [onClose] - Callback appelé à la fermeture du dialog
*/
/**
 * @typedef {Object} InputConfig Configuration pour un type input
 * @property {String} label Le label de l'input
 * @property {String} property La propriété flat style correspondante
 * @property {String|Object} type Le type de l'input. Peut aussi être un type `select`, auquel cas l'élément ajouté est un élément select.
 * Peut être un objet avec une methode getInput()/getElement() pour les inputs personnalisés
 * @property {Object<String, String>} options Les options du select (valeur: libellé)
 * @property {String} label Le label de l'input
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 */
/**
 * @typedef {Object} StyleDialogTabNav Options pour une navigation tertiaire du dialog de style.
 * @property {String} label Libellé de la navigation.
 * @property {FlatStyleForm} form Formulaire de style correspondant.
 * @property {String} [title] Titre associé (attribut title).
 */
/**
 * Classe utilitaire pour la construction d'un dialogue pour la gestion du style.
 *
 * Lie notamment le dialog avec une interaction de sélection, afin d'ouvrir le dialogue
 * lorsqu'il y'a une sélection d'un ou de plusieurs objets.
 * Si aucune sélection n'est donné, la gestion du dialogue est laissée à l'utilisateur·ice.
 */
declare class StyleDialog extends Dialog {
    /**
     * Constructeur du contrôle StyleDialog.
     * @constructor
     * @param {StyleDialogOptions} options Options du constructeur
     */
    constructor(options: StyleDialogOptions);
    /**
     * @protected
     * @param {StyleDialogOptions} options Options du contrôle
     * @override
     */
    protected override _initialize(options: StyleDialogOptions): void;
    /**
     * Nom de la classe (heritage)
     * @private
     */
    private CLASSNAME;
    forms: StyleDialogTabNav[] | undefined;
    icons: {
        Point: string;
        LineString: string;
        Polygon: string;
    } | undefined;
    /**
     * @protected
     * @param {StyleDialogOptions} options Options du contrôle
     * @override
     */
    protected override _initContainer(options: StyleDialogOptions): void;
    /**
     * @protected
     * @param {StyleDialogOptions} options Options du contrôle
     * @override
     */
    protected override _initEvents(options: StyleDialogOptions): void;
    select: Select | undefined;
    /**
     * Renvoie l'intéraction de sélection lié au contrôle
     * @returns {Select} Intéraction de sélection
     */
    getSelect(): Select;
    /**
     * Retourne les formulaires dans le dialogue de style
     * @returns {Array<FlatStyleForm>} Formulaires liés au dialogue de style
     */
    getForms(): Array<FlatStyleForm>;
    /**
     * Récupère un input du dialog en appelant les méthodes `getInput` des formulaires correspondants.
     * Si deux inputs ont la même propriétés, seule la première sera renvoyée.
     *
     * @param {String} property - Le nom de la propriété
     * @returns {DefaultInput|undefined} Input correspondant;
     */
    getInput(property: string): DefaultInput | undefined;
    /**
     * Mets des valeurs dans le formulaire de style
     * @param {Object<String, any>} flatStyle Objet contenant les valeurs à mettre dans les formulaires de style
     */
    setFormValues(flatStyle: any): void;
}
import { Select } from "ol/interaction.js";
import FlatStyleForm from "./FlatStyleForm.js";
import Dialog from "../Toggle/Dialog.js";
import DefaultInput from "../Input/DefaultInput.js";
//# sourceMappingURL=StyleDialog.d.ts.map