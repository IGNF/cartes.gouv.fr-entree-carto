export default styleForm;
/**
 * Formulaire de gestion du style
 * @constant
 * @type {FlatStyleForm}
 */
declare const styleForm: FlatStyleForm;
import FlatStyleForm from "./FlatStyleForm.js";
//# sourceMappingURL=styleForm.d.ts.map