export default ToggleInteraction;
/**
 * @classdesc
 * Contrôle de base créant un toggle avec interaction.
 *
 * @alias ol.control.ToggleInteraction
 * @module Toggle
 */
declare class ToggleInteraction extends Toggle {
    /**
     * Constructeur du contrôle ToggleInteraction.
     * @constructor
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    constructor(options: ToggleInteractionOptions);
    /**
     * Initialise le contrôle ToggleInteraction (appelé par le constructeur).
     * @protected
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    protected _initialize(options: ToggleInteractionOptions): void;
    _boundIntChangeActive: any;
    /**
     * Ajoute les écouteurs d'événements sur les éléments du contrôle.
     * @protected
     * @param {ToggleInteractionOptions} options Options du constructeur
     */
    protected _initEvents(options: ToggleInteractionOptions): void;
    /**
     * Ajoute une interaction au toggle. Enlève la précédente interaction de la carte.
     * @param {Interaction} [interaction] Interaction openlayer
     */
    setInteraction(interaction?: Interaction): void;
    interaction: Interaction | undefined;
    /**
     * Retourne l'interaction lié au toggle.
     * @returns {Interaction} Interaction openlayer (si elle existe)
     */
    getInteraction(): Interaction;
    _onInteractionChangeActive(e: any): void;
}
import Toggle from "./Toggle";
import { Interaction } from "ol/interaction";
//# sourceMappingURL=ToggleInteraction.d.ts.map