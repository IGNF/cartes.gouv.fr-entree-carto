export default InfoControl;
/** Show info on map
 * @extends {ol.control.Control}
 * @private
 */
declare class InfoControl {
    /** Show info on the map
     * @param {String} text Text to show
     */
    setInfo(text?: string): void;
}
//# sourceMappingURL=InfoControl.d.ts.map