type InteractionOptions = {
    /**
     * - L'interaction OpenLayers à ajouter
     */
    interaction: import("ol/interaction").Interaction;
    /**
     * - Libellé de l'interaction
     */
    label: string;
    /**
     * - Icône de l'interaction
     */
    icon?: string | undefined;
};
//# sourceMappingURL=typedefs.d.ts.map