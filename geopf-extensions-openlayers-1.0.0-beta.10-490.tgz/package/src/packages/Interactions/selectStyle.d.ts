export const defaultStyle: {};
/** Default syle
 * @param {String} type Geometry type
 * @param {String} featureType Current feature geometry type or "select"
 * @param {ol.style.Image} img Image style for points
 * @returns {ol.style.Style|Array<ol.style.Style>} Style
 */
export function selectStyle(type: string, featureType: string, img: ol.style.Image): ol.style.Style | Array<ol.style.Style>;
/** Get all points in coordinates
 * @param {Feature|Array<coordinate>} coords Coordinates or feature
 * @returns {Array<coordinate>} Flat coordinates array
 * @private
 */
export function getFlatCoordinates(coords: Feature | Array<coordinate>): Array<coordinate>;
//# sourceMappingURL=selectStyle.d.ts.map