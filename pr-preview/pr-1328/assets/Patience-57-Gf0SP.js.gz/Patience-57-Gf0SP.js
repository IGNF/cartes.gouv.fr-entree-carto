import{_ as s,o as c,c as a,b as n}from"./index-BvP28yUF.js";const o={},t={class:"patience-container"};function r(_,e){return c(),a("div",t,[...e[0]||(e[0]=[n("span",{class:"loader"},null,-1)])])}const i=s(o,[["render",r],["__scopeId","data-v-c0927118"]]);export{i as P};
//# sourceMappingURL=Patience-57-Gf0SP.js.map
