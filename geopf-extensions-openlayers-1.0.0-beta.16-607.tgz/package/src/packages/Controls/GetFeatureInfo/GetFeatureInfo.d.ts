export default GetFeatureInfo;
/**
 * @classdesc
 *
 * GetFeatureInfo button
 *
 * @module GetFeatureInfo
 * @alias ol.control.GetFeatureInfo
 
 */
declare class GetFeatureInfo extends Control {
    /**
     * @constructor
    * @param {Object} options - options for function call.
    * @param {Boolean} [options.button = true] - display the activation button. If false, the control is active by default.
    * @param {Boolean} [options.active] - set the initial active state. This value takes precedence over the button default.
    * @example
    * var getFeatureInfo = new ol.control.GetFeatureInfo();
    * map.addControl(getFeatureInfo);
    */
    constructor(options: {
        button?: boolean | undefined;
        active?: boolean | undefined;
    });
    /**
     * Nom de la classe (heritage)
     * @private
     */
    private CLASSNAME;
    container: HTMLElement;
    element: HTMLElement;
    /**
     * Overwrite OpenLayers setMap method
     *
     * @param {ol.Map} map - Map.
     */
    setMap(map: ol.Map): void;
    getFeatureInfoMarkerOverlay: Overlay | null | undefined;
    /**
     * Returns whether the control is active.
     *
     * @returns {Boolean} true if active, false otherwise
     */
    getActive(): boolean;
    /**
     * Sets whether the control is active.
     *
     * @param {Boolean} active - true to activate the control
     */
    setActive(active: boolean): void;
    active: boolean | undefined;
    activeExplicit: boolean | undefined;
    /**
     * Initialize GetFeatureInfo control (called by GetFeatureInfo constructor)
     *
     * @param {Object} options - constructor options
     * @private
     */
    private initialize;
    uid: any;
    options: {
        collapsed: boolean;
        draggable: boolean;
        auto: boolean;
        button: boolean;
        active: boolean;
    } | undefined;
    button: boolean | undefined;
    /**
     * @type {Boolean}
     * specify if control is collapsed (true) or not (false) */
    collapsed: boolean | undefined;
    /**
     * @type {Boolean}
     * specify if control is draggable (true) or not (false) */
    draggable: boolean | undefined;
    /**
     * @type {String}
     * if specified, the given html string will be displayed if no data are returned by the gfi */
    noDataMessage: string | undefined;
    /**
     * @type {Boolean}
     * specify if control add some stuff auto */
    auto: boolean | undefined;
    /** @private */
    private buttonGetFeatureInfoShow;
    /** @private */
    private panelGetFeatureInfoContainer;
    /** @private */
    private getFeatureInfoPanelDiv;
    /** @private */
    private panelGetFeatureInfoHeaderContainer;
    /** @private */
    private buttonGetFeatureInfoClose;
    /** @private */
    private getFeatureInfoAccordionGroup;
    /** @private */
    private panelGetFeatureInfoEntriesContainer;
    /** @private */
    private noDataMessageDiv;
    /** {Array} specify some events listeners */
    eventsListeners: any[] | undefined;
    /** GFI settings */
    /** @private */
    private pixel;
    coordinates: any;
    /** @public */
    public layers: any;
    /** @private */
    private res;
    /**
     * Create control main container (DOM initialize)
     *
     * @returns {HTMLElement} DOM element
     * @private
     */
    private initContainer;
    /**
     * Add events listeners on map (called by setMap)
     *
     * @param {Map} map - map
     * @private
     */
    private addEventsListeners;
    /**
     * Remove events listeners on map (called by setMap)
     * @private
     */
    private removeEventsListeners;
    /**
     * Tells if control is active or not
     * @private
     * @returns { Boolean } true if active false if not
     */
    private getFeatureInfoIsActive;
    /**
     * Create the DOM element used to display the queried location marker.
     *
     * @returns {HTMLElement} marker element
     * @private
     */
    private _createGetFeatureInfoMarkerElement;
    /**
     * Display the marker at the given GetFeatureInfo coordinates.
     *
     * @param {Array<Number>} coordinate - map coordinate
     * @private
     */
    private _showGetFeatureInfoMarker;
    /**
     * Hide the marker associated with the last GetFeatureInfo request.
     *
     * @private
     */
    private _clearGetFeatureInfoMarker;
    /**
     * event handler
     * @param {Event} e évènement de click
     * @private
     */
    private onMapClick;
    previouslyExpandedLayers: any[] | undefined;
    map: any;
    /**
     * Main render function
     * @param { Layer } layer layer openlayer
     * @returns { Object } gfiLayer
     * {
     *      format : "wmts",
     *      layer: layer,
     *      url :  url          pour wmts et wms
     * }
     */
    getGetFeatureInfoLayer(layer: Layer): any;
    /**
     * Main render function
     * @param { Layer } layer layer openlayer
     * @returns { Array } Array of ol features
     */
    getFeaturesAtClick(layer: Layer): any[];
    /**
     * Main render function
     * @param { Layer } gfiLayer layer openlayer
     * @returns { Object } gfi result
     * {
     *      layername : "layername",
     *      content: "html"
     * }
     */
    getGetFeatureInfoContent(gfiLayer: Layer): any;
    /**
     * Get layer title
     *
     * @param {Layer} gfiLayer - the layer object used by the gfi widget
     * @returns {String} layerTitle - layer title
     */
    getLayerTitle(gfiLayer: Layer): string;
    /**
     * Returns layers that were expanded before the GFI refresh.
     *
     * @param {HTMLElement} accordionGroup - the current accordion group
     * @returns {Array} expanded layers
     * @private
     */
    private getPreviouslyExpandedLayers;
    /**
     * Synchronize accessible state and displayed content for an accordion.
     *
     * @param {HTMLElement} accordion - accordion element
     * @private
     */
    private expandAccordionElement;
    /**
     * Main render function
     * @private
     */
    private displayGetFeatureInfo;
    /**
     * Return layer format
     *
     * @param {ol.layer.Layer} l - layer openlayers
     * @returns {String} format - layer format can be wms, wmts, vector or unknown
     *
     */
    getLayerFormat(l: ol.layer.Layer): string;
    /**
     * Gets HTML content from features array
     *
     * @param {Features[]} features - openlayers features Array
     * @returns {HTMLElement} HTML content.
     */
    features2html(features: Features[]): HTMLElement;
    /**
     * ...
     * @param {Event} e - ...
     * @private
     */
    private onShowGetFeatureInfoClick;
    /**
     * ...
     * @param {Event} e - ...
     * @private
     */
    private onCloseGetFeatureInfoClick;
    /**
     * ...
     * @param {Event} e - ...
     * @private
     */
    private onGetFeatureInfoComputationSubmit;
}
import Control from "../Control";
import Overlay from "ol/Overlay";
import Layer from "ol/layer/Layer";
//# sourceMappingURL=GetFeatureInfo.d.ts.map