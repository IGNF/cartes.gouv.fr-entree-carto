export default SelectingInteraction;
/** Outil de selection et d'interaction avec des features
 *
 */
declare class SelectingInteraction extends Select {
    constructor(options: any);
}
import Select from "ol/interaction/Select";
//# sourceMappingURL=Selecting.d.ts.map