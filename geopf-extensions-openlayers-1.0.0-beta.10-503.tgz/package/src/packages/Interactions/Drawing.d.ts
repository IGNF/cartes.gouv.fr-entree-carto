export default DrawingInteraction;
/**
 * Drawing interaction class.
 *
 * @extends {ol.interaction.Interaction}
 */
declare class DrawingInteraction {
    /**
     * Initialize drawing interaction
     * @param {*} options Openlayers drawing options
     */
    constructor(options: any);
    _type: any;
    info: InfoControl;
    draw: Draw;
    _currentFeature: import("ol").Feature<import("ol/geom").Geometry> | null;
    /**
     * Overwrite OpenLayers setMap method
     *
     * @param {Map} map - Map.
     */
    setMap(map: Map<any, any>): void;
    /** Change the source to collect features
     * @param {VectorSource} source Vector source
     */
    setSource(source: VectorSource): void;
    _source: VectorSource<import("ol").Feature<import("ol/geom").Geometry>> | undefined;
    /** The source to collect features
     * @param {VectorSource} source Vector source
     */
    getSource(): VectorSource<import("ol").Feature<import("ol/geom").Geometry>> | null;
    /** Set interaction active state
     * @param {Boolean} active Active state
     */
    setActive(active: boolean): void;
    /** Get drawing style
     * @returns {ol_style_Style|Array<ol_style_Style>} Style
     */
    getStyle(): ol_style_Style | Array<ol_style_Style>;
    /** Set an image for drawing points
     * @param {ImageStyle} image Image
     */
    setImage(image: ImageStyle): void;
    _image: ImageStyle | undefined;
    /** Get image used for drawing points
     * @returns {ImageStyle} Image
     */
    getImage(): ImageStyle;
    /**
     * Display info message
     * @param {String} info message info
     */
    showInfo(info?: string): void;
}
/** Show info on map
 * @extends {ol.control.Control}
 * @private
 */
declare class InfoControl {
    setInfo(text?: string): void;
}
import Draw from "ol/interaction/Draw";
import VectorSource from "ol/source/Vector";
import ImageStyle from "ol/style/Image";
//# sourceMappingURL=Drawing.d.ts.map