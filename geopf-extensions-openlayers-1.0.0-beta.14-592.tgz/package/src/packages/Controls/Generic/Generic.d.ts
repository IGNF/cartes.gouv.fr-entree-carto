export default Generic;
export type GenericOptions = {
    /**
     * - Identifiant unique du contrôle.
     */
    id?: string | undefined;
    /**
     * - URL de l'icône affichée dans le bouton.
     */
    icon?: string | undefined;
    /**
     * - Texte affiché dans le bouton.
     */
    text?: string | undefined;
    /**
     * - Libellé accessible du bouton.
     */
    title?: string | undefined;
    /**
     * - Action appelée au clic lorsque le contrôle devient actif.
     */
    action?: Function | undefined;
    /**
     * - État actif initial.
     */
    active?: boolean | undefined;
    /**
     * - Position du contrôle sur la carte.
     */
    position?: string | undefined;
    /**
     * - Ajoute ou retire l'espace avec le bouton voisin.
     */
    gutter?: boolean | undefined;
};
/**
 * @typedef {Object} GenericOptions
 * @property {string} [id] - Identifiant unique du contrôle.
 * @property {string} [icon] - URL de l'icône affichée dans le bouton.
 * @property {string} [text] - Texte affiché dans le bouton.
 * @property {string} [title] - Libellé accessible du bouton.
 * @property {Function} [action] - Action appelée au clic lorsque le contrôle devient actif.
 * @property {boolean} [active=false] - État actif initial.
 * @property {string} [position] - Position du contrôle sur la carte.
 * @property {boolean} [gutter] - Ajoute ou retire l'espace avec le bouton voisin.
 */
/**
 * Contrôle bouton générique.
 *
 * @module Generic
 * @alias ol.control.Generic
 */
declare class Generic extends Control {
    /**
     * @param {GenericOptions} [options] - Options du contrôle.
     * @constructor
     * @fires button:clicked
     * @example
     * var generic = new ol.control.Generic({
    *     icon : "img/megaphone.svg",
     *     text : "Annoncer",
     *     action : function (event, active) {
     *         console.log(event, active);
     *     }
     * });
     * map.addControl(generic);
     */
    constructor(options?: GenericOptions);
    CLASSNAME: string;
    options: never;
    uid: string | number;
    active: boolean;
    container: HTMLElement;
    button: HTMLButtonElement;
    /**
     * Retourne l'état actif du contrôle.
     *
     * @returns {Boolean} État actif.
     */
    getActive(): boolean;
    /**
     * Modifie l'état actif du contrôle.
     *
     * @param {Boolean} active - Nouvel état actif.
     */
    setActive(active: boolean): void;
    /**
     * @returns {HTMLElement} Conteneur principal.
     */
    getContainer(): HTMLElement;
    /**
     * @returns {HTMLElement} Conteneur principal.
     * @private
     */
    private _createContainer;
    /**
     * @returns {HTMLButtonElement} Bouton du contrôle.
     * @private
     */
    private _createButton;
    /**
     * @param {MouseEvent} event - Événement de clic.
     * @private
     */
    private _handleClick;
}
import Control from "../Control";
//# sourceMappingURL=Generic.d.ts.map