export default Button;
export type ButtonOptions = {
    /**
     * - Identifiant unique du contrôle.
     */
    id?: string | undefined;
    /**
     * - Classe CSS utilisée pour afficher l'icône.
     */
    icon?: string | undefined;
    /**
     * - Texte affiché dans le bouton.
     */
    text?: string | undefined;
    /**
     * - Libellé accessible du bouton.
     */
    title?: string | undefined;
    /**
     * - Action appelée au clic avec l'événement et le nouvel état actif.
     */
    action?: Function | undefined;
    /**
     * - État actif initial.
     */
    active?: boolean | undefined;
    /**
     * - Position du contrôle sur la carte.
     */
    position?: string | undefined;
    /**
     * - Ajoute ou retire l'espace avec le bouton voisin.
     */
    gutter?: boolean | undefined;
};
/**
 * @typedef {Object} ButtonOptions
 * @property {string} [id] - Identifiant unique du contrôle.
 * @property {string} [icon] - Classe CSS utilisée pour afficher l'icône.
 * @property {string} [text] - Texte affiché dans le bouton.
 * @property {string} [title] - Libellé accessible du bouton.
 * @property {Function} [action] - Action appelée au clic avec l'événement et le nouvel état actif.
 * @property {boolean} [active=false] - État actif initial.
 * @property {string} [position] - Position du contrôle sur la carte.
 * @property {boolean} [gutter] - Ajoute ou retire l'espace avec le bouton voisin.
 */
/**
 * Contrôle bouton générique.
 *
 * @module Button
 * @alias ol.control.Button
 */
declare class Button extends Control {
    /**
     * @param {ButtonOptions} [options] - Options du contrôle.
     * @constructor
     * @fires button:clicked
     * @example
     * var button = new ol.control.Button({
     *     icon : "fr-icon-map-pin-2-line",
     *     text : "Localiser",
     *     action : function (event, active) {
     *         console.log(event, active);
     *     }
     * });
     * map.addControl(button);
     */
    constructor(options?: ButtonOptions);
    CLASSNAME: string;
    options: never;
    uid: string | number;
    active: boolean;
    container: HTMLElement;
    button: HTMLButtonElement;
    /**
     * Retourne l'état actif du contrôle.
     *
    * @returns {Boolean} État actif.
     */
    getActive(): boolean;
    /**
     * Modifie l'état actif du contrôle.
     *
    * @param {Boolean} active - Nouvel état actif.
     */
    setActive(active: boolean): void;
    /**
     * @returns {HTMLElement} Conteneur principal.
     */
    getContainer(): HTMLElement;
    /**
     * @returns {HTMLElement} Conteneur principal.
     * @private
     */
    private _createContainer;
    /**
     * @returns {HTMLButtonElement} Bouton du contrôle.
     * @private
     */
    private _createButton;
    /**
     * @param {MouseEvent} event - Événement de clic.
     * @private
     */
    private _handleClick;
}
import Control from "../Control";
//# sourceMappingURL=Button.d.ts.map